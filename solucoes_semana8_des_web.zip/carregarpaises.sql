USE ex_pais;

INSERT INTO paises (nome, populacao, area) VALUES ('Albânia', 2876591, 28748.00), ('Bósnia e Herzegovina', 3861912, 51197.00),
('Suécia', 10171524, 449964.00), ('Chipre', 1141166, 9521.00),('Croácia', 4154200, 56594.00),('Cazaquistão', 1231534, 124135.00),
('Grécia', 10816286, 131990.00),('Canadá', 37242571, 9984670.00),('Polônia', 38422346, 312679.00);

select * from paises;

